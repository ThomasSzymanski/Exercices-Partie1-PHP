<?
	$cod_deb = '
<script language="JavaScript" type="text/javascript">
	// PARAMETRES
		var message = new Array;
		message[\'ferme\'] = \'<a href="javascript:clo();">OK</a>\';
		message[\'test\'] = \'Ceci est un test<br />\' + message[\'ferme\'];';

	$cod_fin = '
		var bul_hauteur = 200;
		var bul_largeur = 200;
		var bul_ids = 0;

		if(document.getElementById)
			{
			// TAILLE DE L ECRAN
				bul_Y = document.body.clientHeight;
				bul_X = document.body.clientWidth;
				bul_posX = Math.round(bul_X/2);
				bul_posY = Math.round(bul_Y/2)-Math.round(bul_hauteur/2);
			}
		
		function clo()
			{
			if(document.getElementById)
				{
				document.getElementById("bul_ids").style.visibility = \'hidden\';
				}
			}

		function aff(msg)
			{
			if(document.getElementById)
				{
				txt_msg = message[msg];
				document.getElementById("bul_ids").style.visibility = \'visible\';
				document.getElementById("bul_ids").style.top = bul_posY;
				document.getElementById("bul_ids").style.left = bul_posX - (bul_largeur / 2);
				document.getElementById("bul_ids").style.width = bul_largeur;
				document.getElementById("bul_ids").innerHTML = txt_msg;
				}
			}
 </script>

<div class="cal_bul" id="bul_ids" style="position:absolute;visibility:hidden;width:0;z-index:5;"></div>';
Calendrier simple mais joli... v2.0-----------------------------------
Url     : http://codes-sources.commentcamarche.net/source/25751-calendrier-simple-mais-joli-v2-0Auteur  : cs_mfaradayDate    : 13/08/2013
Licence :
=========

Ce document intitul� � Calendrier simple mais joli... v2.0 � issu de CommentCaMarche
(codes-sources.commentcamarche.net) est mis � disposition sous les termes de
la licence Creative Commons. Vous pouvez copier, modifier des copies de cette
source, dans les conditions fix�es par la licence, tant que cette note
appara�t clairement.

Description :
=============

Suite &agrave; une question sur le forum concernant un calendrier pour g&eacute;
rer des &eacute;v&egrave;nements... et bien voila le calendrier... Chez moi, il 
sert &agrave; afficher les anniversaires... 
<br />
<br />Le zip comprend plus
ieurs fichiers :
<br />    - calend.php : le code php...
<br />    - config.ph
p : le fichier de connexion &agrave; la base, et aussi la liste des tables
<br 
/>    - calend.css : le fichier de styles
<br />    - codejs.php : le code perm
ettant l'affichage des bulles dhtml avec la liste des anniversaires
<br />
<br
 />Le codes est comment&eacute;, mais si parfois je n'ai pas &eacute;t&eacute; t
r&egrave;s clair n'h&eacute;sitez pas.
<br />
<br />Prochainement l'ajout, mod
if et suppression des anniversaires.
<br />
<br />J'attend vos commentaires.

<br />
<br />Florian
<br />
<br />MAJ 21.01.2008 : Affichage des &eacute;v&eg
rave;nements entre deux dates.
<br /><a name='source-exemple'></a><h2> Source /
 Exemple : </h2>
<br /><pre class='code' data-mode='basic'>
Vous devez cr�er 
la table tab_rep :

CREATE TABLE `tab_rep` (
  `rep_uid` int(11) NOT NULL aut
o_increment,
  `rep_nom` varchar(150) NOT NULL default '',
  `rep_pre` varchar
(150) NOT NULL default '',
  `rep_als` varchar(50) NOT NULL default '',
  `rep
_ddn` timestamp(8) NOT NULL,
  `rep_pos` int(11) NOT NULL default '0',
  PRIMA
RY KEY  (`rep_uid`)
) TYPE=MyISAM;
</pre>
<br /><a name='conclusion'></a><h2>
 Conclusion : </h2>
<br />- Pas de bug connu. Test&eacute; sous ie, ns, firefo
x et crazy browser. Bon, c'est vrai que les styles ne fonctionne vraiment bien q
ue sous ie donc un bug :-)
<br />
<br />- Un pr&eacute;cision quand &agrave; l
a bulle dhtml, dans la feuille css et dans le code JS, la bulle est de 200*200 p
ixels, j'ai mis le param&egrave;tres overflow &agrave; auto comme &ccedil;a si l
es donn&eacute;es sont trop importantes, de jolis ascenseurs apparaissent... vou
s pouvez changer la taille, mais pensez &agrave; la changer dans les deux fichie
rs.
<br />
<br />MAJ 21.01.2008 :
<br />- Je n'ai pas mis de css pour la page
 de l'intervalle.

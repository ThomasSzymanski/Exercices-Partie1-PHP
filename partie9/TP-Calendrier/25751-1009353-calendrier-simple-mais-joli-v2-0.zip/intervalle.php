<?php
	//---- Inclusion des fichiers
		# Fichier de configuration
		include('config.php');

	//---- Instanciation des variables
		$form = '<script type="text/javascript">'
			.	' function testDate()
					{
					debut = new Date(
						document.getElementById("dAnne").value,
						document.getElementById("dMois").value-1,
						document.getElementById("dJour").value);
					fin = new Date(
						document.getElementById("fAnne").value,
						document.getElementById("fMois").value-1,
						document.getElementById("fJour").value);
					
					if(debut > fin)
						{
						alert("La date de DEBUT doit �tre inf�rieure � la date de FIN.");
						/*exit;*/
						return false;
						}
						
					return true;
					/* alert(debut);
					alert(fin); */
					}'
			.	'</script>';
					


		$form .= '<link rel="stylesheet" type="text/css" href="calend.css" />'."\n";
		$deb = '<br /><div class="txt_cal_deb"><span class="gs">Mode DEBUG actif&nbsp;: </span></div>';

	//---- Les donn�es
		$iDeb['j'] = !isset($_POST['dJour']) ? 0 : $_POST['dJour'];
		$iDeb['m'] = !isset($_POST['dMois']) ? 0 : $_POST['dMois'];
		$iDeb['a'] = !isset($_POST['dAnne']) ? 0 : $_POST['dAnne'];
		$iFin['j'] = !isset($_POST['fJour']) ? 0 : $_POST['fJour'];
		$iFin['m'] = !isset($_POST['fMois']) ? 0 : $_POST['fMois'];
		$iFin['a'] = !isset($_POST['fAnne']) ? 0 : $_POST['fAnne'];
		# Debug
		$debug = !isset($_REQUEST['debug']) ? false : $_REQUEST['debug'];
		
//		echo '<pre>'.print_r($_REQUEST, true).'</pre>';

	if($debug == true) { $deb .= deb('Date d&eacute;but', date('d/m/Y', mktime(0,0,0, $iDeb['m'], $iDeb['j'], $iDeb['a']))); }
	if($debug == true) { $deb .= deb('Date fin', date('d/m/Y', mktime(0,0,0, $iFin['m'], $iFin['j'], $iFin['a']))); }

		$dDeb = date('d/m/Y', mktime(0,0,0, $iDeb['m'], $iDeb['j'], $iDeb['a']));
		$dFin = date('d/m/Y', mktime(0,0,0, $iFin['m'], $iFin['j'], $iFin['a']));
	
//	$form = '';
	$resultat = '';
	$sDeb['j'] = $sDeb['m'] = $sDeb['a'] = '';
	$sFin['j'] = $sFin['m'] = $sFin['a'] = '';
	
	//---- Affichage du formulaire

		# D�but
		for($i=1;$i<=31;$i++)
			{
			$selectedDeb = ($i == $iDeb['j']) ? ' selected="selected"' : '';
			$sDeb['j'] .= '<option value="'.$i.'"'.$selectedDeb.'>'.zer($i).'</option>';
			}
		$sDeb['j'] = '<select name="dJour" id="dJour">'.$sDeb['j'].'</select>';
			
		for($j=1;$j<=12;$j++)
			{
			$selectedDeb = ($j == $iDeb['m']) ? ' selected="selected"' : '';
			$sDeb['m'] .= '<option value="'.$j.'"'.$selectedDeb.'>'.$blo['moi'][zer($j)].'</option>';
			}
		$sDeb['m'] = '<select name="dMois" id="dMois">'.$sDeb['m'].'</select>';
		
		for($k = date('Y')-10; $k <= date('Y')+10; $k++)
			{
			$selectedDeb = ($k == $iDeb['a']) ? ' selected="selected"' : '';
			$sDeb['a'] .= '<option value="'.$k.'"'.$selectedDeb.'>'.$k.'</option>';
			}
		$sDeb['a'] = '<select name="dAnne" id="dAnne">'.$sDeb['a'].'</select>';
			
		# Fin
		for($i=1;$i<=31;$i++)
			{
			$selectedDeb = ($i == $iFin['j']) ? ' selected="selected"' : '';
			$sFin['j'] .= '<option value="'.$i.'"'.$selectedDeb.'>'.zer($i).'</option>';
			}
		$sFin['j'] = '<select name="fJour" id="fJour">'.$sFin['j'].'</select>';
			
		for($j=1;$j<=12;$j++)
			{
			$selectedDeb = ($j == $iFin['m']) ? ' selected="selected"' : '';
			$sFin['m'] .= '<option value="'.$j.'"'.$selectedDeb.'>'.$blo['moi'][zer($j)].'</option>';
			}
		$sFin['m'] = '<select name="fMois" id="fMois">'.$sFin['m'].'</select>';
		
		for($k = date('Y')-10; $k <= date('Y')+10; $k++)
			{
			$selectedDeb = ($k == $iFin['a']) ? ' selected="selected"' : '';
			$sFin['a'] .= '<option value="'.$k.'"'.$selectedDeb.'>'.$k.'</option>';
			}
		$sFin['a'] = '<select name="fAnne" id="fAnne">'.$sFin['a'].'</select>';
			
		
		$form .= '<form action="'.$_SERVER['PHP_SELF'].
			(($debug==true) ? '?debug=true' : '').
		'" method="post">';
		$form .= '<table><tr>';
		$form .= '<td>Date d&eacute;but</td>';
		$form .= '<td>'.$sDeb['j'].$sDeb['m'].$sDeb['a'].'</td>';
		$form .= '<td>Date fin</td>';
		$form .= '<td>'.$sFin['j'].$sFin['m'].$sFin['a'].'</td>';
		$form .= '<td><input type="submit" value="Afficher" onclick="javascript:return testDate();" /></td>';
		$form .= '<td><a href="calend.php" title="Retour au calendrier">Retour</a></td>';
		$form .= '</tr></table>';
		$form .= '</form>';
		
	//---- Les r�sultats
		
		if($iDeb['j'] <> 0 && $iFin['j'] <> 0)
			{
			$resultat .= '<h1>&Eacute;v&egrave;nements entre le '.$dDeb.' et le '.$dFin.'</h1>';

			//---- Function bir
			$req = 'SELECT * FROM tab_rep WHERE date(rep_ddn) > "'.$iDeb['a'].'-'.zer($iDeb['m']).'-'.zer($iDeb['j']).'"
AND date(rep_ddn) < "'.$iFin['a'].'-'.zer($iFin['m']).'-'.zer($iFin['j']).'" order by rep_ddn asc, rep_nom asc, rep_pre asc';
			$res = mysql_query($req, $con);
			$nbr = mysql_num_rows($res);

			if($nbr)
				{
				$resultat .= '<ul>';
				while($result = mysql_fetch_array($res))
					{
					$resultat .= '<li>'.date_fr($result['rep_ddn']).' - '.ucfirst($result['rep_pre']).' '.ucfirst($result['rep_nom']).'</li>';
					}
				$resultat .= '</ul>';
				}
			else
				{
				$resultat .= '<p>Pas de r&eacute;sultat dans cet intervalle.</p>';
				}
			}
		else
			{
			$resultat .= '<h1>Vous devez s&eacute;lectionner une date de d&eacute;but et une date de fin</h1>';
			}
	
	//---- Affichage
		echo $form;
		echo $resultat;
		# Le debug
		if($debug == true) { echo $deb; }

?>
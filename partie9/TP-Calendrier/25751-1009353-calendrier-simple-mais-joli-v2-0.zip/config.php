<?
	//---- D�marrage de la session
		session_name('sescal');
		session_start();
		
		$snm = session_name();
		$sid = session_id();

	//---- D�finition du timezone
	date_default_timezone_set('Europe/Paris');

	//---- Variables de connexion � la base
		$bdd['usr'] = '';
		$bdd['mdp'] = '';
		$bdd['bas'] = '';
		$bdd['hot'] = '';

	//---- Connexion � la base
		$con = mysql_connect($bdd['hot'], $bdd['usr'], $bdd['mdp']);
		$sel = mysql_select_db($bdd['bas'], $con);
		
		# Des erreurs ?
		if(!$con) { echo "Impossible de se connecter &agrave; la base"; exit(); }
		if(!$sel) { echo "Impossible de s&eacute;lectionner la base"; exit(); }
		
	//---- Liste des tables...
		$table['rep'] = 'tab_rep';

	//---- Tableau des jours
		$blo['jou'] = array
			(
			1 => 'Lundi',
			2 => 'Mardi',
			3 => 'Mercredi',
			4 => 'Jeudi',
			5 => 'Vendredi',
			6 => 'Samedi',
			7 => 'Dimanche'
			);
			
	//---- Tableau des mois
		$blo['moi'] = array
			(
			'01' => 'janvier',
			'02' => 'f&eacute;vrier',
			'03' => 'mars',
			'04' => 'avril',
			'05' => 'mai',
			'06' => 'juin',
			'07' => 'juillet',
			'08' => 'ao&ucirc;t',
			'09' => 'septembre',
			'10' => 'octobre',
			'11' => 'novembre',
			'12' => 'd&eacute;cembre'
			);
	
	//---- function debug
		function deb($tit, $txt)
			{
			return '<div class="txt_cal_deb"> - '.$tit.'&nbsp;: '.$txt.'</div>';
			}

	//---- Funtion zer
		# renvoi x ou 0x
		function zer($num)
			{
			if($num < 10 && strlen($num) < 2)
				{
				$num = '0'.$num;
				}
			return $num;
			}

	//----- Function date_fr
		function date_fr($date)
			{
			${0} = explode(' ', $date); 
			${0} = explode('-', ${0}[0]);
			return date('d/m/Y', mktime(0,0,0, ${0}[1], ${0}[2], ${0}[0]));
			}
			
		function pre($tableau)
			{
			return '<pre>'. print_r($tableau, true). '</pre>';
			}
?>
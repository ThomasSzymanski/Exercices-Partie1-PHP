<?
	//---- Inclusion des fichiers
		# Fichier de configuration
		include('config.php');
		# Fichier contenant le code javascript
		include('codejs.php');

	//---- Instanciation des variables
			$calend = '<link rel="stylesheet" type="text/css" href="calend.css" />'."\n";
			$deb = '<br /><div class="txt_cal_deb"><span class="gs">Mode DEBUG actif&nbsp;: </span></div>';
			$messages ='';

	//---- function css
		# renvoi le css correspondant...
		function css($jou, $tst)
			{
			# Cas des cellules vides...
			if($tst == 1)
				{
				$css['L'] = ' class="cel_cal_vid"';
				$css['S'] = '_cal_vid"';
				}
			
			# Cas des dimanches
			if($jou == 7)
				{
				$css['L'] = ' class="cel_cal_dim"';
				$css['S'] = '_cal_dim"';
				}
			# Cas des samedis
			elseif($jou == 6)
				{
				$css['L'] = ' class="cel_cal_sam"';
				$css['S'] = '_cal_sam"';
				}

			# Renvoi le tableau
			return $css;
			}
			
	//---- function jou
		# renvoi le css correspondant...
		function jou($jou, $j, $m, $a, $num_jou, $moi, $ann)
			{
			# Cas des jours "normaux"
			switch($jou)
				{
				case 1:
				case 2:
				case 3:
				case 4:
				case 5:
					$css['L'] = ' class="cel_cal_jou"';
					$css['S'] = '_cal_jou"';
					break;
				# Cas des samedis
				case 6:
					$css['L'] = ' class="cel_cal_sam"';
					$css['S'] = '_cal_sam"';
					break;
				# Cas des dimanches
				case 7:
					$css['L'] = ' class="cel_cal_dim"';
					$css['S'] = '_cal_dim"';
					break;
				}
			
			# Cas de aujourd'hui...
			if($j == $num_jou && $m == $moi && $a == $ann)
				{
				$css['L'] = ' class="cel_cal_auj"';
				$css['S'] = '_cal_auj"';
				}

			# Renvoi le tableau
			return $css;
			}
	
	//---- Function cut
		function cut($txt, $len)
			{
			# Transforme tous les caract�res HTML
			$txt = html_entity_decode($txt);
			# Test la longueur
			$txt = strlen($txt) > $len ? substr($txt, 0, $len).'.' : $txt;
			# ReTransforme tous les caract�res HTML
			$txt = htmlentities($txt);
			
			# Renvoi le txt coup�...
			return $txt;
			}

	//---- Function bir
		function bir($jou, $moi, $ann, $tab, $con, $debug)
			{
			$req = 'select * from '.$tab.' where dayofmonth(rep_ddn) = "'.$jou.'" and month(rep_ddn) = "'.$moi.'" order by rep_ddn asc, rep_nom asc, rep_pre asc';
			$res = mysql_query($req, $con);
			$nbr = mysql_num_rows($res);
			if($nbr) { $ret[1] = $nbr; $ret[2] = $res; } else { $ret[1] = ''; }

			$ret[0] = '';
			if($debug == true) { $ret[0] .= deb($jou.'-'.$moi.'-'.$ann, $nbr); }
			
			return $ret;
			}

	//---- Funtion lnk
		function lnk($moi, $ann, $snm, $sid, $debug)
			{
			$lnk = '?rub=cal&pag=acc&'.$snm.'='.$sid.'&moi='.$moi.'&ann='.$ann;
			if($debug == true) { $lnk .= '&debug=true'; }
			return $lnk;
			}
			
	//---- Variables
		# Debug
		$debug = !isset($_GET['debug']) ? false : $_GET['debug'];
		
	//---- Calculs pr�alables
		
		# Aujourd'hui
			$auj = array
				(
				'j' => date('d'),
				'm' => date('m'),
				'a' => date('Y')
				);
				
		# Si pas de date fournies alors date d'aujourd'hui
			$moi = !isset($_GET['moi']) ? $auj['m'] : $_GET['moi'];
			$ann = !isset($_GET['ann']) ? $auj['a'] : $_GET['ann'];
			
		# Permier jour du mois (1-> lundi, 7-> dimanche)
			// Cr�e le timestamp du 01/moi/ann
			$tsp = mktime(0, 0, 0, $moi, 1, $ann);

			// Calcul le num�ro du premier jour
			// avec 0-> Dimanche...
			$pjo = date('w', $tsp);

			// Dimanche = 7, pas 0
			$pjo = $pjo == 0 ? 7 : $pjo;

			// D�bug ?
			if($debug == true) { $deb .= deb('N� premier jour', $pjo); }
			
		# Nombre de jours dans le mois
			// Cr�e le timestamp
			// en fait renvoi le der jour du mois...
			$tsp = mktime(0, 0, 0, $moi, 0, $ann);

			// Renvoi le jour en num�rique
			$djo = strftime('%d', $tsp);

			// D�bug ?
			if($debug == true) { $deb .= deb('Nombre de jours', $djo); }

		# Calculs des mois & ann�es pr�c�dents & suivants
			// Mois pr�c�dent...
			$tsp = mktime(0, 0, 0, $moi - 1, 1, $ann);
			$mpr['moi'] = date('m', $tsp);
			$mpr['ann'] = date('Y', $tsp);

			if($debug == true) { $deb .= deb('Mois pr�c�dent', $mpr['moi'].'-'.$mpr['ann']); }

			// Mois suivant...
			$tsp = mktime(0, 0, 0, $moi + 1, 1, $ann);
			$msu['moi'] = date('m', $tsp);
			$msu['ann'] = date('Y', $tsp);

			if($debug == true) { $deb .= deb('Mois suivant', $msu['moi'].'-'.$msu['ann']); }

			// Ann�e pr�c�dente...
			$tsp = mktime(0, 0, 0, $moi, 1, $ann - 1);
			$apr['moi'] = date('m', $tsp);
			$apr['ann'] = date('Y', $tsp);

			if($debug == true) { $deb .= deb('Ann�e pr�c�dente', $apr['moi'].'-'.$apr['ann']); }

			// Ann�e suivante...
			$tsp = mktime(0, 0, 0, $moi, 1, $ann + 1);
			$asu['moi'] = date('m', $tsp);
			$asu['ann'] = date('Y', $tsp);

			if($debug == true) { $deb .= deb('Ann�e suivante', $asu['moi'].'-'.$asu['ann']); }

		# D�marrage du tableau de navigation
			// Tableau
			$calend .= '<table class="cal">';
			// Ligne
			$calend .= '<tr>';

		# Cellules
			// Aujourd'hui
			$lnk = lnk($auj['m'], $auj['a'], $snm, $sid, $debug);
			$txt = '[ Auj. ]';
			$tit = 'Aujourd\'hui ('.$auj['j'].'/'.$auj['m'].'/'.$auj['a'].')';

			$calend .= '<td class="cel_cal_opt"><a href="'.$lnk.'" class="lnk_cal_tod" title="'.$tit.'">'.$txt.'</a></td>';

			// Mois pr�c�dent
			$lnk = lnk($mpr['moi'], $mpr['ann'], $snm, $sid, $debug);
			$txt = cut($blo['moi'][$mpr['moi']], 4);
			$tit = 'Mois pr�c�dent ('.$blo['moi'][$mpr['moi']].' '.$mpr['ann'].')';

			$calend .= '<td class="cel_cal_opt"><a href="'.$lnk.'" class="lnk_cal_nav" title="'.$tit.'">&lt; '.$txt.'</a></td>';

			// Mois actuel
			$txt = cut($blo['moi'][$moi], 4);			

			$calend .= '<td class="cel_cal_act">'.$txt.'</td>';

			// Mois suivant
			$lnk = lnk($msu['moi'], $msu['ann'], $snm, $sid, $debug);
			$txt = cut($blo['moi'][$msu['moi']], 4);
			$tit = 'Mois suivant ('.$blo['moi'][$msu['moi']].' '.$msu['ann'].')';

			$calend .= '<td class="cel_cal_opt"><a href="'.$lnk.'" class="lnk_cal_nav" title="'.$tit.'">'.$txt.' &gt;</a></td>';

			// Ann�e pr�c�dente
			$lnk = lnk($apr['moi'], $apr['ann'], $snm, $sid, $debug);
			$txt = $apr['ann'];
			$tit = 'Ann�e pr�c�dente ('.$blo['moi'][$apr['moi']].' '.$apr['ann'].')';

			$calend .= '<td class="cel_cal_opt"><a href="'.$lnk.'" class="lnk_cal_nav" title="'.$tit.'">&lt; '.$txt.'</a></td>';

			// Ann�e actuelle
			$txt = $ann;

			$calend .= '<td class="cel_cal_act">'.$txt.'</td>';

			// Mois suivant
			$lnk = lnk($asu['moi'], $asu['ann'], $snm, $sid, $debug);
			$txt = $asu['ann'];
			$tit = 'Ann�e suivante ('.$blo['moi'][$asu['moi']].' '.$asu['ann'].')';

			$calend .= '<td class="cel_cal_opt"><a href="'.$lnk.'" class="lnk_cal_nav" title="'.$tit.'">'.$txt.' &gt;</a></td>';

			// Intervalle
			$calend .= '<td class="cel_cal_opt"><a href="intervalle.php" class="lnk_cal_nav" title="S&eacute;lectionner un intervalle">P&eacute;riode</a></td>';
			
		# fin du tableau
			// Ligne
			$calend .= '</tr>';
			// Tableau
			$calend .= '</table>';


		# D�marrage du calendrier
			// Tableau
			$calend .= '<table class="cal">';
			// Ligne
			$calend .= '<tr>';

		# Affiche les ent�tes du tableau
			for($a = 1; $a <= 7; $a++)
				{
				$calend .= '<th class="cet_cal_0">'.$blo['jou'][$a].'</th>';
				}

		# Nouvelle ligne
			// Ligne
			$calend .= '</tr>';
			// Ligne
			$calend .= '<tr>';

		# Instancie le compteur de jour
			// (de 1 � 7 pour la semaine)
			$nbr_jou = 1;
			// (de 1 � $djo pour le mois)
			$num_jou = 1;

		# Affiche des cases vides pour commencer...
			for($b = 1; $b < $pjo; $b++)
				{
				$css = css($b, 1);
				$calend .= '<td'.$css['L'].'>&nbsp;</td>';
				$nbr_jou++;
				}
			
		# On commence l'affichage des jours...
			for($c = 1; $c <= $djo; $c++)
				{
				$css = jou($nbr_jou, $auj['j'], $auj['m'], $auj['a'], $num_jou, $moi, $ann);
				$bir = bir($num_jou, $moi, $ann, $table['rep'], $con, $debug);
				$deb .= $bir[0];

				# Pas d'anniversaire
				if($bir[1] == '')
					{
					$calend .= '<td'.$css['L'].'><div class="txt'.$css['S'].'">'.zer($num_jou).'</div></td>';
					}
				# Des anniversaires
				else
					{
					$calend .= '<td'.$css['L'].'><a class="lnk'.$css['S'].'" href="#" onclick="aff(\''.$ann.zer($moi).zer($num_jou).'\');">'.zer($num_jou).'</a></td>';
					$messages .= 'message[\''.$ann.zer($moi).zer($num_jou).'\'] = "';
					while($tab = mysql_fetch_array($bir[2]))
						{
						$messages .= '<li>'.$tab['rep_pre'].' '.$tab['rep_nom'].'</li>';
						}
					$messages .= '" + message[\'ferme\'];'."\n";
					}
				
				$num_jou++;
				
				if($num_jou <= $djo)
					{
					if($nbr_jou == 7)
						{
						$nbr_jou = 1;
						# Nouvelle ligne
							// Ligne
							$calend .= '</tr>';
							// Ligne
							$calend .= '<tr>';
						}
					else
						{
						$nbr_jou++;
						}
					}
				}

			if($debug == true) { $deb .= deb("N� dernier jour", $nbr_jou); }

		# On affiche des cases vides pour finir...
			if($nbr_jou < 7)
				{
				
				for($d = $nbr_jou + 1; $d <= 7; $d++)
					{
					$css = css($d, 1);
					$calend .= '<td'.$css['L'].'>&nbsp;</td>';
					}
				}

		# fin du tableau
			// Ligne
			$calend .= '</tr>';
			// Tableau
			$calend .= '</table>';

		
	//---- Affichage
		# Le calendrier
		echo $calend;
		# Le code JS
		echo $cod_deb;
		echo $messages;
		echo $cod_fin;
		# Le debug
		if($debug == true) { echo $deb; }

?>